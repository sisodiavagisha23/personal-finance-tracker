# FinTrack – Personal Finance Tracker

A full-stack MERN application to record income and expenses, visualise spending with charts, and track your balance over time. Secured with JWT authentication.

**Live demo:** _add your Vercel URL here_ · **API:** _add your Render/Railway URL here_

## Features

- Secure registration and login (JWT, bcrypt-hashed passwords)
- Protected routes on both frontend and backend
- Add and delete income/expense transactions (optimistic UI on delete)
- Pie chart (spending by category) and bar chart (monthly income vs expense)
- Summary cards: total income, expenses, balance
- Filters by type, category and date range; charts and cards update with filters
- Export filtered transactions as CSV
- Responsive layout (mobile, tablet, desktop) and light/dark mode
- Toast notifications, form validation and loading states

## Tech stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, Vite, Tailwind CSS, Context API |
| Charts | Recharts |
| Backend | Node.js, Express |
| Database | MongoDB Atlas, Mongoose |
| Auth | JWT, bcryptjs |
| Security | helmet, CORS allow-list, rate limiting on auth routes |
| Deployment | Vercel (client), Render or Railway (server) |

## Project structure

```
finance-tracker/
├── client/                 # React app
│   └── src/
│       ├── api/            # Axios instance + interceptors
│       ├── context/        # Auth and Theme providers
│       ├── components/     # Reusable UI (StatCard, Charts, Filters, ...)
│       ├── pages/          # Login, Register, Dashboard
│       └── utils/          # Formatting helpers, categories
└── server/                 # Express API
    ├── config/             # DB connection
    ├── models/             # User, Transaction
    ├── middleware/         # JWT auth, error handling
    ├── controllers/        # Request handlers
    ├── services/           # Business logic (queries, aggregation, CSV)
    └── routes/
```

## API reference

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | – | Create account, returns token |
| POST | `/api/auth/login` | – | Log in, returns token |
| GET | `/api/auth/me` | ✔ | Current user |
| GET | `/api/transactions` | ✔ | List (query: `type`, `category`, `startDate`, `endDate`, `page`, `limit`) |
| POST | `/api/transactions` | ✔ | Add transaction |
| DELETE | `/api/transactions/:id` | ✔ | Delete transaction |
| GET | `/api/transactions/summary` | ✔ | Totals, category breakdown, monthly series |
| GET | `/api/transactions/export` | ✔ | Download CSV |

Send the token as `Authorization: Bearer <token>`.

## Local setup

**Prerequisites:** Node.js 18+, a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster.

```bash
# 1. Backend
cd server
cp .env.example .env      # fill in MONGO_URI and JWT_SECRET
npm install
npm run dev               # http://localhost:5000

# 2. Frontend (new terminal)
cd client
cp .env.example .env
npm install
npm run dev               # http://localhost:5173
```

### Environment variables

**server/.env**

| Variable | Description |
|----------|-------------|
| `PORT` | API port (default 5000) |
| `MONGO_URI` | MongoDB Atlas connection string |
| `JWT_SECRET` | Long random string (e.g. `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`) |
| `JWT_EXPIRES_IN` | Token lifetime, e.g. `7d` |
| `CLIENT_URL` | Allowed frontend origin(s), comma-separated |

**client/.env**

| Variable | Description |
|----------|-------------|
| `VITE_API_URL` | API base URL, e.g. `https://your-api.onrender.com/api` |

## Deployment

### Backend → Render (or Railway)
1. Push the repo to GitHub.
2. Render → **New Web Service** → select repo, set **Root Directory** to `server`.
3. Build command `npm install`, start command `npm start`.
4. Add the environment variables above. Set `CLIENT_URL` to your Vercel URL.
5. In MongoDB Atlas → Network Access, allow `0.0.0.0/0` (or Render's outbound IPs).

### Frontend → Vercel
1. Vercel → **New Project** → select repo, set **Root Directory** to `client`.
2. Framework preset: Vite. Add `VITE_API_URL` pointing to your deployed API (ending in `/api`).
3. Deploy. `vercel.json` handles client-side routing.

## Screenshots

_Add screenshots of the login page, dashboard (light and dark) and mobile view here._

## Possible next steps

Edit transactions, recurring transactions, monthly budgets per category, PDF export, email reports (Nodemailer), PWA support, unit/integration tests.

## License

MIT
